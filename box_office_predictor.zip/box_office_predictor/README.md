# 🎬 Box Office Revenue Predictor

A machine learning application that predicts box office revenue for films using the **TMDB 5000 Movie Dataset** from Kaggle.

---

## 📁 Project Structure

```
box_office_predictor/
├── data/                        # Place your Kaggle CSVs here
│   ├── tmdb_5000_movies.csv
│   └── tmdb_5000_credits.csv
├── src/
│   ├── data_loader.py           # Data loading & merging
│   ├── preprocessing.py         # Cleaning & feature engineering
│   ├── visualizations.py        # EDA plots (matplotlib)
│   ├── model.py                 # Linear Regression + Random Forest
│   └── explainability.py        # SHAP analysis
├── outputs/                     # All plots saved here
├── models/                      # Saved model artifacts
├── main.py                      # Entry point — runs full pipeline
├── requirements.txt
└── README.md
```

---

## 🚀 Setup & Run

### 1. Install dependencies
```bash
pip install -r requirements.txt
```

### 2. Add your data
Download from Kaggle and place both CSVs in the `data/` folder:
- `tmdb_5000_movies.csv`
- `tmdb_5000_credits.csv`

### 3. Run the pipeline
```bash
python main.py
```

---

## 🔧 Features Used

| Feature | Description |
|---|---|
| `budget` | Production budget (USD) |
| `runtime` | Film duration (minutes) |
| `popularity` | TMDB popularity score |
| `vote_average` | Average user rating |
| `vote_count` | Number of votes |
| `genres_count` | Number of genres |
| `cast_size` | Number of cast members |
| `crew_size` | Number of crew members |
| `has_homepage` | Whether the film has a website |
| `release_month` | Month of release |
| `release_year` | Year of release |
| `spoken_languages_count` | Number of spoken languages |
| `production_companies_count` | Number of production companies |

---

## 📊 Pipeline Steps

1. **Data Loading** — Merge movies + credits datasets
2. **Preprocessing** — Clean nulls, parse JSON columns, engineer features
3. **EDA Visualizations** — Distribution plots, correlation heatmap, scatter plots
4. **Modeling** — Linear Regression (primary) + Random Forest (comparison)
5. **Evaluation** — MAE, RMSE, R² for both models
6. **SHAP Explainability** — Feature importance, summary plots, waterfall charts

---

## 📈 Outputs

All plots are saved to `outputs/`:
- `01_revenue_distribution.png`
- `02_budget_vs_revenue.png`
- `03_correlation_heatmap.png`
- `04_top_genres.png`
- `05_revenue_by_month.png`
- `06_model_comparison.png`
- `07_actual_vs_predicted.png`
- `08_shap_summary.png`
- `09_shap_bar.png`
- `10_shap_waterfall.png`

---

## 🧠 Models

| Model | Notes |
|---|---|
| Linear Regression | Baseline model — interpretable, fast |
| Random Forest | Ensemble comparison — captures non-linearity |

Both models are saved as `.pkl` files in `models/`.
